# Rework Playbook — kid-friendly Poki battle-royale, phone-first

Drop this file plus `PAD-SAMPLER.md`, `shell.css`, and `shell.js`
into the repo of the game you are reworking and point the session at
it. It is the complete record of what was tuned in the Floor is
LMAO! rework and why, written as instructions. The reference
implementation is `poki/` in `pavlovskisad/floor_is_lmao`.

## 0.5 The studio shell (read this first)

Everything around the game is a unified studio signature, shared
VERBATIM across all titles as two files:

- **`shell.css`** — the entire look: fonts, splash, wordless
  tutorial framework and scene styles, menu, buttons, HUD, joystick,
  popups, results/winner overlays, boombox canvas.
- **`shell.js`** — the entire UX plumbing: Poki wrapper, boot
  choreography (splash → tutorial → menu wake), iOS audio unlock +
  silent-switch bypass, whole-screen joystick, screen shake, wins
  storage, and the boombox + tape mute-switch prop.

**Do not rebuild any of this — copy the two files unchanged.** The
game integrates through one call, `SHELL.init(config)`; the full
config and provided-globals reference is the header comment of
`shell.js`. Sections 1-4 below describe what the shell implements —
they are the spec and the rationale, kept so you understand what
you're integrating with (and can fix the shell if a game exposes a
bug; fixes flow back by copying the file to the other repos).

**Per-game identity slots** (everything else is shared):
- Mascot: splash bouncer emoji, tutorial faces, the close button's
  morph glyph (`data-mascot` attribute on `#btn-howto-close`), the
  in-game character model.
- Accent hue: the `:root` CSS vars in shell.css are the one allowed
  per-game override (gold here; give siblings their own).
- Tutorial SCENES: the framework is shell; compose this game's 8
  cards from the scene styles to match its mechanics.
- Music: genre loop pack + manifest (see PAD-SAMPLER.md), and a
  freshly composed weird win fanfare in the same spirit.
- The game itself: arena, tiles, physics, scene dressing, sim.
- Copy: title, tagline, popup words, storage key.

## 0. What a rework is

Take an existing 10-player battle-royale prototype and produce a
fully client-side, kid-safe, phone-first build for poki.com and
standalone Vercel deployment.

- One `index.html`, no build step, no package.json for the game.
- Solo player vs 9 bots (port the server sim into the browser).
- Strip everything crypto/accounts/adult: wallets, payments, logins,
  leaderboards, prize copy, slurs, edgy labels. Poki reviews for kids.
- Replace text with visuals wherever possible; whatever text remains
  should be lowercase, friendly, and minimal (i18n-free by design).
- Self-host every asset. The Poki SDK script is the ONLY allowed
  external request.

## 1. Boot choreography (get this exactly right)

The boot is a staged sequence where every animation gets its own
stage time. Nothing visible or audible may happen before its moment.

1. **Loading splash** covers everything (z-index 300): game title in
   the display font, one bouncing character (DOM emoji is fine), a
   real progress bar over the core assets, a short lowercase label.
   Readiness = character model + any scene-prop models + at least one
   audio loop in EVERY sampler band (not just drums; on LTE the other
   bands stay dead-silent pads otherwise). 12s safety timeout so a
   stalled download never blocks the game. Fade out 0.45s.
2. **Poki's `gameLoadingFinished` fires when the splash drops**, not
   at first render. Poll a `game-ready` body class.
3. **Wordless tutorial** (section 2) is revealed under the splash,
   shown by default on every load.
4. Taps during splash/tutorial do ONLY invisible work: audio unlock +
   silent-switch bypass. No music, no prop animations. The menu wake
   is exclusively triggered by the tutorial close handler.
5. Tutorial close: play button morph (section 2) → modal drops →
   200ms beat → THEN the music prop animates on-screen (here: tape
   flies into the boombox) and the menu music wakes.

**iOS audio rules (hard-won, do not relearn):**
- iOS grants audio activation only on `pointerup`/`touchend`/`click`/
  `keydown` class events. `pointerdown` does NOT count. Listen on all
  four, retry every gesture, self-remove only once
  `ctx.state === 'running'` AND the silent element is playing.
- The ring/silent switch mutes WebAudio ("ambient" session). Bypass:
  on first gesture play a looping generated-silence `<audio>` element
  (0.1s WAV built in JS, volume 0.01, playsinline) and set
  `navigator.audioSession.type = 'playback'` where available.
- Create the AudioContext early (suspended) so loop decoding happens
  during the splash; `resume()` inside the gesture.
- Anything the SDK's init callback runs happens with NO gesture
  (PokiSDK.init resolves seconds after load): gate all autoplay/prop
  animation on `ctx.state === 'running'`.

## 2. Wordless tutorial

Fullscreen (not a boxed modal), shown by default on load, zero words.
Symbols only: +1 ❤️ / -1 💔 numbers, 💀, 💥, ♪, ⭐, 🏆. Nothing to
localize — a genuine Poki plus.

- Full-bleed grid of ~8 cards, `1fr 1fr` portrait, `repeat(4, 1fr)`
  landscape, each card = one looping CSS pictogram scene (~2-3.5s
  loops, staggered delays where scenes have multiple actors).
- Scene inventory to adapt per game: good tile (+1 ❤️ high bounce),
  bad tile (-1 💔 low hop), disappearing tile (blink → actor falls
  through, 💀 pops), collision (two actors + 💥 + both -1 💔),
  music mechanic (pulsing pads + rising ♪), controls (joystick ring
  with orbiting knob + drifting actor), arena shrink (mini floor grid
  whose outer ring blinks out), win condition (⭐-marked actor
  outlasts two falling ones, 🏆 pops).
- One round close button (~72px circle, accent color, "▶" glyph — a
  symbol, not text). **On tap it double-flips (rotateY 720°, scale to
  1.4, 0.6s), swaps its glyph to the game's mascot at ~210ms while
  edge-on/motion-blurred, drops its background so only the face
  spins**, then the modal dismisses at ~640ms and the button resets.
  Guard against double-taps.
- MUST fit one phone screen with no scroll: verify programmatically
  at 390×844 AND 375×667 (`box.scrollHeight <= clientHeight`, close
  button fully visible). `max-height: calc(100dvh - 28px)` +
  overflow-y auto as a landscape safety only.
- `prefers-reduced-motion`: all tutorial animations off.

## 3. Look and feel

**Fonts — the studio signature.** **Jersey 15** (display) +
**DotGothic16** (body) are the house typography, identical in every
game — they ship inside shell.css + `fonts/`. Never revert to Press
Start 2P / VT323 (the most AI-default fonts on the web). If the
house fonts ever change, change them in the shell and propagate;
display pixel fonts vary hugely in width, so rescale display sizes
and screenshot-verify after any swap.

**Palette:** near-black blue ground (#0b0f18 family), one accent
(here #ffd84a gold) for all interactive/marker UI, neon green/red
for good/bad tiles (color IS the language: green = on/heal, red =
off/hurt — tutorial, pads, and popups all reuse it).

**Scene dressing** (all procedural, no lights beyond ambient+hemi):
- Emissive tile floor, per-tile blink on landings, warn-blink before
  collapse.
- Glass walls, padel-court style: near-invisible pane, crisp 2px top
  edge line with a 12px glow gradient under it, two soft diagonal
  sheen streaks drifting slowly sideways (each pane its own pace),
  front pane extra faint and streak-free so the play area stays
  clean. Physics: reflect with restitution 0.62; walls retire
  (physics off + ~2s fade) when the arena shrink begins — the
  safety net dissolves exactly as difficulty rises. Impact ripples
  (additive rings, pooled) on hits >1.4 m/s.
- A big slow-spinning mirror-ball mascot overhead (chrome matcap is
  a free win: strip the model's textures, apply a procedural
  oil-slick matcap canvas) + 3 additive light cones whose apexes sit
  ABOVE the camera frustum (top corners + center) so beams pour in
  from off-screen; fog disabled on the cones.
- Camera: fixed, portrait fov 62 / dist 27 / height 14, landscape
  42/22/12, lookAt (0, 1.8, arenaCenterZ).

**Characters:** never render emoji into canvas→WebGL textures — iOS
Safari draws black blobs. Use a real GLB. Pipeline for a heavy
source model: `gltf-transform simplify --ratio 0.02 --error 0.002`
→ `resize --width 1024 --height 1024` → `draco`; 17MB/390k-tris
became 300KB/8.4k-tris. Render **unlit** (MeshBasicMaterial with the
baked map) — it reads bright like an emoji and skips PBR cost on
low-end phones. Per-instance material clones for i-frame blink.
Squash-stretch from vy (x,z: 1−0.22t; y: 1+0.34t; t = clamp(vy/10)).
Characters tumble like balls: spin axis = (vz, 0, −vx)/|v|, angle =
speed·dt / (height/2), applied to a spinner pivot at ball center
UNDER the squash-scale group. DOM emoji (HUD, tutorial) is fine —
only canvas-texture emoji is broken.

## 4. Game feel and controls

- Air control accel 22 (raised from 14) + **air brake**: when input
  opposes horizontal velocity, extra drag `exp(-3.2·dt)` — mid-air
  direction changes bite instead of floating. This is the single
  biggest feel win; port it.
- Ground control rate 14, maxHSpeed 6.5, gravity 9, greens launch
  vy 11 / reds 6.
- **Joystick**: whole-screen touch (spawns under the finger), but
  ALWAYS visible during play at a bottom-right rest position with a
  soft pulsing accent glow (2.2s box-shadow breath) — returns to
  rest on release, hidden on menu/results, never rendered for
  keyboard-only devices (`ontouchstart`/maxTouchPoints gate).
- **Screen shake**: decaying random camera jitter (amp·k², k =
  remaining/duration), applied to stored base position, restored
  exactly. Big on win (0.42, 900ms), small when the player takes any
  hit (0.16, 280ms — trigger on the player's invulnT rising edge).
- Arena: ~2.75-unit tiles (they read well on phones), 7×9 grid.
  Battle-royale shrink: outer ring retires at 40s (2.6s warn blink),
  next at 75s, capped at 2 rings so a 3×5 core always remains.
- HUD: hearts row + neon-sign alive counter (white core, colored
  halo text-shadow stack, slow breath).

## 5. Player agency and feedback (the music-game glue)

Read `PAD-SAMPLER.md` for the engine. The agency layer on top, all
of which must be ported for the game to feel responsive:

- **Instant slice** (`padHit`): player triggering a not-playing pad
  hears the head of that loop on the next 16th (~90ms max).
- **Impact boost**: player stomping an already-playing pad bumps
  that layer to 1.65x on the next 16th, back in ~0.5s, + band flash.
- **Priority**: a player's staged pad cannot be overwritten by bots;
  once applied, the band is bot-locked for 16 beats (accents refresh
  12). Player stagings also skip the band cooldown at apply time.
- **Queued markers**: EVERY staged pad shows a pulsing ring on the
  exact landing tile until it applies — gold for the player, dim
  blue for bots. Without the bot markers, loops "start themselves".
- **Progress rings**: every playing loop shows a GarageBand-style
  filling circle on the exact tile that started it (per-slot; a
  doubled band shows two). Place via the sim's own tileCenter math —
  never on computed band rows (they end up between tiles).
- Popups stay plain (+1 ❤️ / -1): no stem-name text.

## 6. The round's musical arc (sequencing)

- **Menu**: attract bots play the sampler; music from first unlocked
  gesture. The music prop (boombox tape) is the mute switch —
  eject = mute this screen only; every round start and menu wake
  re-docks and unmutes (music is default-on; sticky mute was a bug
  factory).
- **Countdown**: `fadeStop(2.7)` — a LINEAR master fade the length
  of the countdown, silence lands just before "1", one quiet beat,
  GO. (Do not use the fast stop: it kills loops in 0.1s.) Sources
  release only after inaudible; a start during the fade cancels it.
- **Round**: starts silent; `awaitFirstPad` holds the drums
  keep-alive until the first real landing stages something — the
  track genuinely begins with the first hit. Keep-alive then keeps
  the floor from ever going fully mute.
- **Deaths** peel one layer from a random playing melodic band, on
  the grid, no one-shot SFX (off-grid one-shots read as broken
  against real stems).
- **Win**: synthesized fanfare, deliberately weird, not a tada — the
  reference recipe: 5 ring-modulated square blips climbing a
  not-quite-scale (0.11s apart, RM 26+19i Hz), a shutter-gated
  (9 Hz square LFO) 4-saw chord sliding 0.97→1.03 of its pitches
  over ~1s, a 524→28 Hz tape-stop drop. Route it around the master
  fade (master fades at round end). Make a DIFFERENT weird fanfare
  per game — same spirit, new recipe. Plus: disco spin-up ~10x and
  stage-cone strobe for 4.4s, results panel delayed 1.8s on wins
  (1.5s on losses), winner overlay is a light golden radial veil
  (NOT the dark plate — the party must stay visible through it) with
  a glowing wobbling placement number.
- **Ad breaks**: everything mutes (separate flag from user mute so
  they compose), resumes after.

## 7. Poki + deploy specifics

- SDK: `gameLoadingFinished` (splash drop), `gameplayStart` (round
  start), `gameplayStop` (round end), `commercialBreak` (PLAY
  AGAIN). Every call guarded so the game runs identically with the
  SDK absent. Know that the SDK serves REAL ads on any domain — the
  Vercel deploy will show ads on replay; decide per game whether to
  domain-gate it.
- `vercel.json` at repo root: `installCommand: ""`, buildCommand
  copies the game dir + heavy optional assets into `dist/`,
  `outputDirectory: "dist"`, immutable cache headers for
  glb/mp3/ogg/m4a/woff2/wasm.
- Poki zip: game dir contents with `index.html` at zip root; trim
  the loop manifest to 2-3 songs and leave heavy optional props out
  (the modules degrade silently when files are missing).
- Audio formats: OGG + M4A both, always; probe
  `canPlayType('audio/ogg; codecs="vorbis"')` and fetch only the
  supported format (iOS must not download 24 files it cannot
  decode).

## 8. Verification (how to know it works before the phone test)

Headless Chromium + Playwright against the exact Vercel build
output. Chromium there has no AAC — the m4a path will fall back to
synth; that is the fallback chain working, not a bug. What to
assert, minimum:

- Splash: shown on load, real progress, drops only when core assets
  ready, `game-ready` set, tutorial revealed after.
- Tutorial: no scroll at 390×844 and 375×667, close button fully
  visible; tap during tutorial unlocks audio but does NOT dock the
  prop or start music; close → morph → menu wake order.
- Sampler: all loops decode to EXACT frame counts (equal lengths per
  band), pad staging → queued marker on the exact tile → applies on
  the bar → progress ring on that tile; bot staging blocked during
  player lock; countdown fade curve (audible early, 0 before GO);
  round starts silent until first landing.
- Round flow: eject mid-round mutes, play-again restores music AND
  tape; win fires fanfare + shake + winner overlay class; wins
  counter persists.
- Physics: wall bounce pre-shrink, sail-out death post-shrink; all
  characters contained while walls up.
- Autoplay policy flag `--autoplay-policy=user-gesture-required`
  approximates iOS gating for boot tests.

**Only a real iPhone can verify**: silent-switch bypass, actual
audio sync feel, LTE loading pacing, and touch ergonomics. Ship to
Vercel early and often; the user tests on the phone every round of
changes — small commits, screenshot everything headless first.

## 9. Session workflow that worked

Ship in small verified increments (branch → test headless → merge to
main → Vercel auto-deploys → phone test). When the user reports
"feels wrong/random/laggy", suspect sequencing and feedback checks
before mechanics — nearly every such report here was a visibility or
timing gap (hidden animations, un-telegraphed bot actions, bar-delay
disconnects), not broken logic. Every knob lives in the CFG block or
the JUNGLE constants; keep it that way.
