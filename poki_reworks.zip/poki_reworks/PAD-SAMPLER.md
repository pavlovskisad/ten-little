# The floor pad sampler (JUNGLE module) — porting guide

The music-generation system in this game: the arena floor is a live
pad grid where every tile maps to a loop, and gameplay generates the
soundtrack. This doc is written so a fresh session can lift the
module into another game and re-skin it with a different music genre
in one sitting.

## Where the code lives

Everything is inside `index.html` (the game is deliberately a single
file). The module is self-contained in the **second** `<script>`
block, marked with these section comments:

- `JUNGLE — the floor as a live pad sampler` — the whole engine:
  constants, loader, scheduler, pad API (~250 lines)
- `Synth fallback` (`jungleSynthLoop`) — WebAudio-rendered loops used
  when no audio files are present
- The silent-switch bypass (`unlockSilentSwitch`) and the
  `DOMContentLoaded` wiring at the bottom of the block

The game side (first `<script>` block) touches it in exactly six
places — search for `JUNGLE.` to find them all:

| Hook | Where | What it does |
|---|---|---|
| `JUNGLE.ensure()` | DOMContentLoaded + first pointerdown | create AudioContext, prefetch + decode all loops |
| `JUNGLE.start()` | round start, menu wake | clock on, master gain up |
| `JUNGLE.stop()` | round end | fade out, stop all loops |
| `JUNGLE.pad(stem, gx, isGreen)` | landing handler in `renderSim` | a landing presses a pad |
| `JUNGLE.padHit(stem, gx)` | same, player-only | instant audible slice for tap feedback |
| `JUNGLE.impactBoost(stem)` | same, player-only | short loudness bump when stomping a playing pad |
| `JUNGLE.onDeath()` | death handler in `frame()` | strips one playing melodic band |

Plus `JUNGLE.setMuted(bool)` (ad breaks) and
`JUNGLE.setUserMuted(bool)` (the boombox tape = mute switch), and two
game-side helpers the module calls back: `stemForRow(gz)` (row band →
stem name) and `blinkBandForStem(stem)` (visual flash on toggle).

## The mental model

- **4 bands** (`drums`, `bass`, `stabs`, `fx`), each holding up to
  `JUNGLE_MAX_SLOTS` (2) simultaneous loops; adding past the cap
  evicts the oldest, a red stop peels the oldest, and doubled bands
  pull each layer down ~3dB (`JUNGLE_DUAL_ATT`) so summed energy
  stays near single-loop level. Rows of the floor map to bands
  (front rows = drums), columns map to songs, so pad (row band,
  column) = one specific loop.
- **One master clock** (`JUNGLE_MASTER_BPM`, 170 here). Every loop is
  conformed to it via `playbackRate = masterBpm / songBpm`. Keep the
  source tempos within ~±4% of master or the pitch shift gets audible.
- **Green landing** = stage that pad's loop to start *from its top* on
  the **next bar** (replaces whatever the band plays). **Red landing**
  = stop the band on the **next beat**. Last landing before the
  boundary wins; per-band cooldowns (in beats) stop ten characters
  from thrashing a band. Drums auto-restart on the bar if the floor
  ever goes silent.
- **padHit** = instant feedback: plays the head of the pad's own loop
  on the next 16th note (~90ms worst case) while the full loop waits
  for the bar. Player-only, and skipped when that loop already plays.
- Loops never need to stay mutually phase-locked (each starts from
  its own top), but each must loop seamlessly, hence the exact-frame
  trimming below.

## Asset pipeline (per genre)

1. Source a **stem pack**: one royalty-free track split into layer
   stems is ideal (all stems of one song are guaranteed coherent).
   Multiple songs = the mashup pool. Check the license allows game
   distribution.
2. Stems must be **exact bar counts** at a known BPM (packs almost
   always are — verify: `duration / (240 / bpm)` should be integer).
3. Encode each stem to **OGG (vorbis, q3) + M4A (AAC ~112k)** — OGG
   for everyone, M4A because iOS Safari cannot decode OGG:
   ```
   ffmpeg -i stem.wav -c:a libvorbis -q:a 3 drums.ogg
   ffmpeg -i stem.wav -c:a aac -b:a 112k -movflags +faststart drums.m4a
   ```
   To trim a 32-bar stem to 16 bars first:
   `-af atrim=end_sample=$(python: round(16 * 240/BPM * 44100))`
4. Layout: `loops/<song>/{drums,bass,stabs,fx}.{ogg,m4a}` plus
   `loops/manifest.json`:
   ```json
   { "bars": 16,
     "songs": [ { "dir": "euphoria", "bpm": 170, "name": "Euphoria (Fm)" } ] }
   ```
   Per-song `"bars"` overrides the top-level default.

## Hard-won pitfalls (do not relearn these)

- **Memory**: decoded PCM is float32. 24 stereo 16-bar loops ≈ 190MB
  — kills phones. The loader trims every loop to `JUNGLE_LOOP_BARS`
  (8) of its own tempo and downmixes to mono at decode (~45MB total).
  Budget before adding songs.
- **Exact frame counts**: vorbis decodes with a few frames of tail
  padding, AAC with ~2112 frames of encoder priming at the *head*.
  `conformLoop` trims to `round(bars * 240/bpm * sampleRate)` frames
  — small excess drops the tail, large excess (>1600) drops the head.
  Skip this and loops click and drift.
- **iOS audio unlock**: the AudioContext must be resumed inside a
  user gesture. `ensure()` is safe to call early (context loads
  suspended); `start()` must be reachable from the first tap.
- **iOS ring/silent switch**: WebAudio uses the "ambient" session and
  is silent with the mute switch on. `unlockSilentSwitch()` plays a
  looping generated-silence `<audio>` element on first gesture (and
  sets `navigator.audioSession.type = 'playback'`), which moves the
  session to "playback". Without this, most phones hear nothing.
- **Ad breaks**: Poki requires silence during `commercialBreak()`.
  The `Poki` wrapper calls `bbAdPause`/`bbAdResume`, which call
  `JUNGLE.setMuted`.
- **Scheduler**: a 30ms `setInterval` with 0.18s lookahead walks beat
  boundaries against `ctx.currentTime`. All gain changes are
  scheduled (`setTargetAtTime`) at boundary timestamps, never applied
  immediately. Never use `Date.now()` for musical time.

## Re-skinning knobs

| Knob | Meaning |
|---|---|
| `JUNGLE_MASTER_BPM` | the shared clock; set to your pack's center tempo |
| `JUNGLE_LOOP_BARS` | bars kept per loop (memory ∝ this) |
| `JUNGLE_STEM_GAIN` | per-band mix levels |
| `JUNGLE_MASTER` | master volume |
| cooldowns in `applyBeat` | thrash resistance (beats; drums 8, others 4) |
| bar vs beat quantum | starts on bars, stops on beats — in `applyBeat` |
| `stemForRow` (game side) | which rows drive which band |
| `gx % songCount` in `pad()` | column → song mapping |

Genre notes: the 4-band split (drums/bass/harmonic/atmos) is
genre-agnostic — for house rename mentally to kick/bass/chords/vox,
for trap 808s go in `bass`. Halftime genres may want loop starts
quantized to 2 bars (change the `onBar` condition to
`beat % 8 === 0`).

## Porting checklist

1. Copy the second `<script>` block sections listed above.
2. Wire the six game-side hooks + `stemForRow`/`blinkBandForStem`
   equivalents for your board/zone shape.
3. Build `loops/` with the pipeline above; set `JUNGLE_MASTER_BPM`.
4. Test: all loops log `[jungle] loaded`, `barLen` matches the
   manifest bpm, a green pad starts its loop on the bar, red stops on
   the beat, drums self-revive, ad mute works.
5. On a real iPhone: silent switch on → music still plays.
