# Chungus Bounce House

Browser-based survival game prototype. Ten chunguses (chunky Big Chungus rabbits) jumping inside a giant inflatable bounce house. Each consecutive jump goes higher than the last. Above wall height = risk of flying out and dying. Mid-air bumps drain HP and reset jump streak. A hunter walks the perimeter shooting high-jumpers. Carrots drift at high altitudes for healing. Last one standing wins.

Currently single-player feel test with bot opponents. Built as branded variant of "Big Chungus" meme. Will eventually become a multiplayer crypto pot game once the feel is dialed in.

---

## Tech stack

- three.js r128 from cdnjs (global script, not modules)
- Pure HTML/CSS/JS, single file, no build step, no package.json yet
- Hand-rolled physics — gravity, ballistic arcs, walls, collisions
- Fully procedural geometry — no GLB assets, no textures needed
- No audio, no MP, no persistence

## Files

- `chungus.html` — the entire game (~1300 lines, single file)
- `references/` — original Meshy AI assets (not used; kept for reference)
  - `bounce-house-meshy.glb` — original inflatable castle model (Meshy AI generated, ~30MB)
  - `chungus-meshy.glb` — original Big Chungus character with jump animation (Meshy AI generated, ~16MB, rigged + skinned)
- `CLAUDE.md` — this doc

The procedural-everything path was chosen for fast iteration on physics and visuals without 46MB of model downloads. The Meshy GLBs are kept in `references/` in case you want to drop in real models later — see the "Next tasks" section.

## How to run

```
python3 -m http.server 8000
```

Open `http://localhost:8000/chungus.html`. Or just open `chungus.html` directly in a browser via file:// — works because there are no asset fetches.

For phone testing on local network:
```
# Mac's local IP:
ipconfig getifaddr en0
# Phone: http://<that-ip>:8000/chungus.html
```

---

## Game mechanics

### Round flow

- 10 chunguses spawn jittered in a ring inside the bounce house (1 player marked with yellow ring + spinning gold star, 9 bots in random pastel colors)
- Bounce house floor at y=0; walls 5 units tall; bounce house is 11.2 wide × 16 deep, shifted +1.5 in Z so the front edge sits near the bottom of the screen
- Continuous physics: each chungus falls, lands, bounces back up with velocity = `baseVy * jumpMulti^jumpCount`
- Round ends when 1 chungus remains

### Jump escalation (the core forcing function)

- First jump: vy=7, peak height 1.75m, ~1 second airtime
- Each subsequent jump multiplies velocity by 1.13 (aggressive curve)
- Peak heights: J1=1.75, J2=2.24, J3=2.86, J4=3.65, J5=4.66, **J6=5.94 ← first jump over the wall**, J7=7.59, J8=9.14 (cap reached, vy=16 max)
- Cap at jumpVyMax=16 prevents infinite escalation — all jumps from J8 onward have the same peak

### Elimination paths

1. **Fly out**: position above wallH while outside arena bounds → flagged escaping → no more wall collision → falls outside → eliminated after 1.5s grace
2. **Drained (bumps)**: mid-air collision with another chungus → both lose 1 HP, both jumpCount reset to 0, knockback impulse, vertical velocity 0.55×, 700ms i-frames
3. **Drained (hunter)**: shot by hunter projectile → -1 HP, knockback in projectile direction, vy 0.55×

### Bounce floor randomness

Real bounce house floors aren't flat. Every floor contact adds a small random horizontal kick `0.6 + jumpCount * 0.08` m/s in random direction. Early jumps are mostly controllable; high jumps get squirrely. This is the main reason "just bounce in place" doesn't work — you'll drift unpredictably and either hit a wall, get bumped, or fly out.

### Player controls

- Touch: tap anywhere on screen, virtual joystick appears at touch point, drag from there. Multi-touch safe.
- Keyboard: WASD or arrows.
- Ground control: snappy (exponential approach to target velocity, rate 14)
- Air control: weaker (4.5 m/s² accel) — you commit to your trajectory when you leave the ground
- Max horizontal speed capped at 5.5 m/s

### Bot AI

Each bot has a `boldness` factor (0–1) at spawn. Bots periodically re-pick wander direction every 0.8–2.2s based on:
- Low HP or low boldness → head toward center (safe)
- High boldness + player alive → head toward player (aggression)
- Otherwise → random wander

Movement is throttled to 85% of player max speed so player has slight edge.

### Carrots (healing pickups)

- Spawn at altitude 3.5–6m, randomly within arena bounds
- Max 3 on screen at any time
- Spawn rate: every 10s ± 5s jitter
- Visual: orange cone (pointing down) with green leaves on top, floats with bob animation, slowly spins, has glowing halo at base
- Pickup radius 0.85m — chungus body touches carrot → +1 HP (capped at hpMax=10)
- Designed risk/reward: tempting to jump high to grab one, but high = hunter targets you + escape risk

### Hunter (perimeter shooter)

- Appears 8s after game start
- Small olive-uniformed figure with orange hunting hat and rifle, scaled 1.6× (taller than chunguses so visible from across)
- Walks the perimeter outside the bounce house at radius = max(arenaX, arenaZ) + 1.8
- Targets the closest alive chungus above y=4.0 (i.e. anyone near or above wall height)
- Aim sequence:
  1. Hunter rotates to face the target's current position
  2. Pulsing red ring appears on the ground beneath target (tracks target's actual movement during aim, so player knows they're being aimed at)
  3. Aim takes 1300ms — this is the dodge window
  4. On fire: hunter predicts where target will be when projectile arrives, using:
     - 65% lead factor (not perfect — leaves dodge room)
     - Random spread ±0.25m
     - Ballistic Y (accounts for gravity)
  5. Projectile fires at 32 m/s, glowing orange ball
- Cooldown 2800ms between shots
- Hit: -1 HP, knockback 4.0 m/s in projectile direction, vy *= 0.55, 700ms i-frames

Survival strategy: don't be predictable. Stationary in air = dead. Steady drift = dead. Direction changes during the 1300ms aim window = lives.

---

## Code architecture

### CFG block (top of script)

All tunable values live in `CFG`. Organized into sections:
- Arena dimensions: `arenaX`, `arenaZ`, `arenaCenterZ`, `wallH`
- Physics: `baseVy`, `jumpMulti`, `jumpVyMax`, `gravity`, `wallBounce`
- Controls: `airControlAccel`, `groundControlRate`, `maxHSpeed`
- HP: `hpMax`, `iframeMs`, `bumpKnockback`, `bumpVerticalDamp`
- Visuals: `chungusScale`
- Carrots: `carrotMaxOnScreen`, `carrotSpawnEveryMs`, `carrotSpawnJitterMs`, `carrotPickupR`, `carrotMinY`, `carrotMaxY`
- Hunter: `hunterSpawnAtMs`, `hunterMoveSpeed`, `hunterAimMs`, `hunterShootCooldownMs`, `hunterTargetMinY`, `hunterProjectileSpeed`, `hunterDamageR`, `hunterKnockback`, `hunterLeadFactor`, `hunterAimSpread`

### State object `S`

Holds runtime state — time `t`, `running`, `ended`, `player` ref, `chunguses` array, `alive` count, input `inputX/Y`, `carrots`, `projectiles`, `hunter`, `targetMarker`, `nextCarrotAtMs`.

### Subsystems

- `buildBounceHouse()` — procedural inflatable: yellow vinyl floor (sized to arenaX/Z, offset by arenaCenterZ), 4 walls in red/teal/red horizontal sections, all half-transparent (sides at 0.55, front at 0.35), 4 corner towers (teal cylinder + red cone), yellow glowing danger line around the top at wallH
- `buildProceduralChungus(tint, isPlayer)` — fat gray bunny: round body, white belly patch, two long ears with pink insides, beady eyes, pink nose, buck teeth, suggested feet. Player gets bright red-orange tint + always-on emissive glow + spinning gold star above head
- `spawnChunguses()` — places 10 chunguses in jittered ring inside bounce house, player slot random, player also gets a glowing yellow ground ring that pulses and follows them
- `updatePhysics(dt)` — per-frame: input → drag → speed cap → gravity → integrate → check escape flag → wall collision (inset by chungusR for visual clearance) → ground contact (bounce inside, flyOut outside) → squash-stretch animation tied to vy → HP-driven emissive glow → star spin → ground ring follow
- `applyPlayerInput`, `applyBotAI` — control logic, split for player vs bot
- `checkBumps()` — O(n²) chungus pair sphere check; on overlap: HP loss, jumpCount reset, knockback, i-frames
- `buildCarrot`, `spawnCarrot`, `updateCarrots(dt)` — periodic spawn, bob + spin animation, pickup detection against chunguses
- `buildHunter`, `spawnHunter`, `updateHunter(dt)` — state machine 'walking' ↔ 'aiming', perimeter walk, target selection, prediction at fire-time
- `fireProjectile`, `updateProjectiles(dt)`, `hitChungusWithProjectile` — ballistic projectile, hit detection, damage application
- `eliminate(c, reason)`, `flyOut(c)`, `checkEnd()`, `endRound()` — death + round termination logic
- Touch + keyboard event listeners — whole-screen joystick on touchstart

### Camera

Fixed perspective, repositions on resize. Portrait FOV 62°, landscape 42°. Camera looks at the bounce house center (0, 1.8, arenaCenterZ). Aspect-aware distance.

---

## Style preferences

Prose (comments, UI text, this doc):
- No em-dashes (use commas, semicolons, or periods)
- No "not X but Y" contrast constructions
- No throat-clearing openers ("Note that…", "Importantly…")
- Active voice with human subjects
- Specifics over abstractions
- Trust the reader, state facts directly

Code:
- Single file is fine for prototype phase
- Comments explain WHY not WHAT
- All tunable values exposed in CFG block at top
- Use `console.log('[subsystem] message')` for debug, not silent

---

## Next tasks (priority order)

1. **Sound** — Tone.js layer. Bounce thump, carrot crunch, hunter rifle shot, projectile whoosh, bump punch. Make it land.
2. **Better chungus models** — `references/chungus-meshy.glb` has a rigged + skinned animated chungus from Meshy AI. Replace procedural with this for production. Load with GLTFLoader, clone with SkeletonUtils for 10 instances, drive animation mixer from physics state (squash at landing, stretch at peak). Watch out: 16MB asset, slow on mobile.
3. **Better bounce house model** — `references/bounce-house-meshy.glb` is the Meshy AI inflatable castle. Could replace the procedural one for production polish. Currently procedural is the right call because the Meshy mesh's coordinate system was unclear and didn't match physics dimensions. Plus 30MB. If integrated, scale and position carefully to match physics bounds (arenaX/Z, arenaCenterZ).
4. **Hunter visual polish** — rifle muzzle flash on fire, walking animation (currently slides), reload pose during cooldown.
5. **More pickups** — speed boost, double jump, shield (skip next hit). Designed around the same risk/reward as carrots (you have to jump high to get them).
6. **Round timer / forcing function** — currently the only forcing function is bumps and the hunter. Maybe a slowly closing ceiling? Faster hunter? Hunter spawns a buddy mid-round?
7. **Multiplayer port** — Colyseus server with server-authoritative physics, replacing bots with real players. 20Hz state sync, client-side interpolation.
8. **Crypto layer** — entry payment, escrow contract on Base, asymmetric payout (3rd refund, 2nd 2.5x, 1st 5.5x). PAXG settlement, hooks into musa rails.

---

## Recent iteration history

For context on design decisions:

- Started with literal Meshy AI assets (chungus.glb + bounce-house.glb). Bounce house mesh didn't match physics dimensions, chunguses bounced on invisible plane below the house. Replaced with procedural.
- Tried base64-embedded GLB to avoid CORS issues in claude.ai artifacts. Inflated file to 200KB+ but worked. Abandoned in favor of fully procedural for iteration speed.
- Multiple camera iterations. Settled on portrait fov 62, dist 25, height 15, landscape fov 42, dist 19, height 12. Look-at at (0, 1.8, arenaCenterZ).
- Wall heights bumped multiple times. Final wallH=5 — chungus ears (~1 unit above position) stay below wall top through more jumps, reducing visual clipping. Plus inset wall collision by 0.6×chungusR so body never visually clips wall mesh.
- Front wall went solid → invisible → transparent (0.35) once we wanted to see inside cleanly. Side walls also transparent (0.55) for consistency.
- Hunter evolution: started with simple position-recorded shooting, then added velocity prediction (became too deadly), then softened with partial lead factor (0.65) and random spread (0.25). Sweet spot is current.
- Jump multi: 1.10 → 1.13 (aggressive). Cap: 15 → 16.

---

## What good looks like for the next session

A chungus bounce house that feels like a real cartoon. Big Chungus characters squashing and stretching as they bounce. Carrots glow tantalizingly above the walls — going for them is a real decision. The hunter is a clear and present threat — you see them aim, you have to dodge. Sound thickens every event: thumps, shots, crunches, bumps. Round flow has natural rhythm: safe early jumps, peer-pressure escalation, hunter pressure, late-round desperation. Last chungus standing wins. Ready to wrap a crypto pot around it.
